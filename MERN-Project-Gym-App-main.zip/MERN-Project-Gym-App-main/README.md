Done:
1. Basic Styling + MainPage/Register/SignIn Pages
2. Location 
3. Type of workout 
4. Timings 
5. Rate

ToDo:
1. Implement search by gym, rate, timings
2. Pop up card of trainers
3. More css design pls
